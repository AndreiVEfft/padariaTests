package entity;

import exceptions.ProdutoInvalidoException;

public class Produto {

    private int id;
    private String nome;
    private double preco;
    private int quantidade;
    private String tipo;

    public String getTipo() {
        return tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    private Produto(int id, String nome, double preco,int quantidade,String tipo) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.tipo = tipo;
    }

    public Produto() {}

    public static Produto createProduto(int id, String nome, double preco,int quantidade, String tipo){
        if(nome.isBlank() ){
            throw new ProdutoInvalidoException("Há campos obrigatórios não preenchidos!");
        }
        if(preco <= 0){
            throw new ProdutoInvalidoException("Valor digitado é inválido, favor validar!");
        }
        Produto produto = new Produto(id,nome.toUpperCase(),preco,quantidade,tipo);

        return produto;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", preco=" + preco +
                ", quantidade=" + quantidade +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
