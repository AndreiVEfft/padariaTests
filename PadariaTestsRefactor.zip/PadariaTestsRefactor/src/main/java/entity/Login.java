package entity;

public class Login {

    private Cliente cliente;
    private String cpf;
    private String senha;

    public Login(Cliente cliente){
        this.cliente= cliente;
        this.senha = createSenha();
    }

    public String createSenha(){
        String senhaFinal = cliente.getNome().substring(0,3) + cliente.getCpf().substring(0,3);
        return senhaFinal;
    }
    public String getSenha() {
        return senha;
    }

    public boolean validarLogin() {
        String senhaFinal = cliente.getNome().substring(0,3) + cliente.getCpf().substring(0,3);
        if(!cliente.getCpf().isEmpty() && senha.equalsIgnoreCase(senhaFinal)){
            return true;
        }
        else{
            return false;
        }
    }
}
