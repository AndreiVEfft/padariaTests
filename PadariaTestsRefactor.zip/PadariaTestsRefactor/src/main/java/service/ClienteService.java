package service;

import daos.ClienteDAO;
import entity.Cliente;

import static entity.Cliente.createUser;

public class ClienteService {
        private final ClienteDAO clienteDAO;

        public ClienteService(ClienteDAO clienteDAO) {
            this.clienteDAO = clienteDAO;
        }

        public Cliente consultarPorCpf(String cpf) {
            if (cpf == null || cpf.isBlank() || cpf.length() != 11) {
                throw new IllegalArgumentException("CPF inválido");
            }
            return clienteDAO.consultarPeloCpf(cpf);
        }

        public void cadastrarCliente(String nome, String cpf, String telefone) {
            Cliente cliente = createUser(nome, cpf, telefone,0);
            clienteDAO.salvar(cliente);
        }
    }

