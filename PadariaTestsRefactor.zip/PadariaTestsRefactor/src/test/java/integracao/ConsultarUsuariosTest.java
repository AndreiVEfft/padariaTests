package integracao;

import daos.ClienteDAO;
import entity.Cliente;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

public class ConsultarUsuariosTest {
    @Test
    public void consultarListaUsuariosTest(){
        //Arrange
        ClienteDAO dao = new ClienteDAO();
        //Act
        List<Cliente> clientes = dao.consultar();
        //Assert
        Assertions.assertNotNull(clientes);
    }
    @Test
    public void consultarUsuarioUnicoTest(){
        //Arrange
        ClienteDAO dao = new ClienteDAO();
        //Act
        Cliente cliente = dao.consultarPeloCpf("11122233344");
        //Assert
        Assertions.assertNotNull(cliente.getCpf());
        System.out.println(cliente.toString());
    }
    @Test
    public void consultarUsuarioUnicoComCpfInvalidoTest(){
        //Arrange
        ClienteDAO dao = new ClienteDAO();
        //Act
        Cliente cliente = dao.consultarPeloCpf("1112233344");
        //Assert
        Assertions.assertNull(cliente.getCpf());
        System.out.println(cliente.toString());
    }
}
