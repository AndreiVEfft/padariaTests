package sistema;

import daos.ClienteDAO;
import org.junit.jupiter.api.Test;
import service.ClienteService;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

public class ClienteServiceTest {

    @Test
    void deveLancarExcecaoQuandoCpfForInvalido() {
        ClienteDAO clienteDAO = mock(ClienteDAO.class);
        ClienteService service = new ClienteService(clienteDAO);

        assertThrows(IllegalArgumentException.class, () -> {
            service.consultarPorCpf("123"); // CPF curto
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.consultarPorCpf(""); // vazio
        });
    }
}

